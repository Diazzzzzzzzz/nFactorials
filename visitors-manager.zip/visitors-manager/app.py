from flask import Flask, render_template, request, session, redirect, url_for, g
import pandas as pd


from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import create_engine

app = Flask(__name__)
app.secret_key = "\x12f\x07\x97?\xb0\xe4+bL\xbe\x07'\xe5\xaa\x84\x03K\xf7\xa2\xcf\x7f(\r\xe6\xbd\xa05\xd4|\xc4\x19"

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:26082001@localhost/guests_management'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True


file_db = 'mysql://root:26082001@localhost/guests_management'
my_conn = create_engine('mysql://root:26082001@localhost/guests_management')

db = SQLAlchemy(app)
app.app_context().push()

# db models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(length=40))
    password = db.Column(db.String(length=40))



    def __init__(self, id, username, password):
        self.id = id
        self.username = username
        self.password = password

class Visitors(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date)
    time = db.Column(db.Time)
    total_number = db.Column(db.Integer)
    admin = db.Column(db.String(length=80))
    shift_manager = db.Column(db.String(length=80))

    def __init__(self, id, date, time, total_number, admin, shift_manager):
        self.id = id
        self.date = date
        self.time = time
        self.total_number = total_number
        self.admin = admin
        self.shift_manager = shift_manager



@app.before_request
def before_request():
    g.user = None

    if 'user_id' in session:
        cursor = my_conn.execute("SELECT * FROM user WHERE id=%s", session['user_id'])
        user = cursor.fetchone() # using sqlalchemy, but we get whole row, not a single element and able to manipulate: user.id/user.username...
        g.user = user

@app.route('/login', methods=['GET', 'POST'])
def login_page():
    if request.method == 'POST':
        session.pop('user_id', None)

        username = request.form['username']
        password = request.form['password']

        # id = request.form['id']

        q = "select * from user where username='%s'" % username
        my_cursor = my_conn.execute(q)
        user = my_cursor.fetchone()

        if user.password and user.password == password:
            session['user_id'] = user.id
            return redirect(url_for('data_page'))

        return redirect(url_for('login_page'))

    return render_template('login.html')

@app.route('/data', methods=['GET', 'POST'])
def data_page():
    if not g.user:
        return redirect(url_for('login_page'))

    cursor = my_conn.execute('select * from %s' % g.user.username)
    all_data = cursor.fetchall()
    return render_template('data.html', visitors=all_data)

@app.route('/counter')
def counter_page():
    return render_template('counter.html')

@app.route('/log-out')
def log_out():
    session.pop('user_id', None)
    return redirect(url_for('login_page'))

@app.route('/register', methods=['GET', 'POST'])
def register_page():
    if request.method == 'POST':

        username = request.form['reg-username']
        password = request.form['set-password']
        repeat_password = request.form['rpt-password']

        if password == repeat_password:
            my_conn.execute("insert into user(username, password) values('%s', '%s')" % (username, password))
            my_conn.execute("create table %s(id INT AUTO_INCREMENT PRIMARY KEY, action_date DATE, action_time TIME, total_number INT, admin_name VARCHAR(50), shift_manager VARCHAR(50))" % username)
            return redirect(url_for('success'))

    return render_template('register.html')

@app.route('/successful_registration')
def success():
    return render_template('successful-registration.html')

@app.route('/insert', methods=['POST'])
def insert():
    if request.method == 'POST':
        action_date = request.form['date']
        action_time = request.form['time']
        total_number = request.form['num']
        admin_name = request.form['admin']
        shift_manager = request.form['manager']

        my_conn.execute("insert into %s(action_date, action_time, total_number, admin_name, shift_manager) values('%s','%s',%s,'%s','%s')" % (g.user.username, action_date, action_time, total_number, admin_name, shift_manager))

        return redirect(url_for('data_page'))

@app.route('/update', methods=['GET', 'POST'])
def update():
    pass


@app.route('/delete/<id>', methods=['GET', 'POST'])
def delete(id):

    my_conn.execute("delete from %s where id=%s" % (g.user.username, id))
    return redirect(url_for('data_page'))


if __name__ == '__main__':
    app.run(port=10000, debug=True)
