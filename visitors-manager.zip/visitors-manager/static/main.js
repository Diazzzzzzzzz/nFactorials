
let countNum = document.getElementById("count-num")
let saveNum = document.getElementById("save-num")

const formEl = document.getElementById("send-form")
const inputEl = document.getElementById("people-num")
const inputAdmEl = document.getElementById("admin-name")

const addItemEl = document.getElementById("add-item-form")
const bodyEl = document.body
const tableEl = document.getElementById("table-section")

// const editForm = document.getElementsByClassName("form")


let count = countNum.innerText
function increment() {
    console.log("The button is clicked")
    count++
    countNum.textContent = count
}

function decrement() {
    console.log("The button os clicked")
    count--
    countNum.textContent = count
}

function reset() {
    count = 0
    countNum.textContent = "0"
}

function save() {
    saveNum.textContent += count + " - "
}

/* form functions */

function addChild() {
    formEl.style.display = 'block'
    renderData()
}

function closeForm() {
    formEl.style.display = 'none'
}

function renderData() {
    inputEl.value = count
    inputAdmEl.value = name
}

function addItemForm() {
    addItemEl.style.display = 'block'

    bodyEl.style.backgroundColor = "rgba(0,0,0, 0.4)"
    tableEl.style.filter = "brightness(20%)"
}

function addEditForm() {
    editForm.style.display = 'block'
    bodyEl.style.backgroundColor = "rgba(0,0,0, 0.4)"
    tableEl.style.filter = "brightness(20%)"
}