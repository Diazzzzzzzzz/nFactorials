action = 'y'

while action == 'y':

    while 1:
        try:
            num1 = float(input('Enter the first number: '))
        except ValueError:
            print('Enter a convertable-to-a-number value!')
        else:
            break

    while 1:
        try:
            num2 = float(input('Enter the second number: '))
        except ValueError:
            print('Enter a convertable-to-a-number value!')
        else:
            break

    operation = input('Enter and operation(+,-,*,/,^): ')

    match operation:
        case '+':
            print(f'Result of {num1} + {num2} is {num1+num2}')
        case '-':
            print(f'Result of {num1} + {num2} is {num1-num2}')
        case '*':
            print(f'Result of {num1} + {num2} is {num1*num2}')
        case '/':
            try:
                num1 / num2
            except ZeroDivisionError:
                print('You cannot divide a number by 0! Try again. float division by zero')
                continue
            else:
                print(f'Result of {num1} + {num2} is {num1/num2}')
        case '^':
            print(f'Result of {num1} + {num2} is {num1**num2}')

    action = input('Do you want to try again (y/n) ? ')
